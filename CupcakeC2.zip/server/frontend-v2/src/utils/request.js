import api from '../api/index'
export default api
